<?php
print 'This is the Home Page...';