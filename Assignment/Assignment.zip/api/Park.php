<?php

class Park {

}